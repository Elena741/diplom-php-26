<h2><?php echo e($title); ?></h2>
<ol class="breadcrumb">
	<li><a href="<?php echo e(route('admin.index')); ?>"><?php echo e($parent); ?></a></li>
	<li class="active"><?php echo e($active); ?></li>	
</ol>
